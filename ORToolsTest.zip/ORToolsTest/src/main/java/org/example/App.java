package org.example;

import java.io.IOException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception {
        String path = "/Users/fengzhongjie/instances/Falkenauer_t60_00.txt";
        BinPackingSolver binPackingSolver = new BinPackingSolver();
        binPackingSolver.solveBBP(path);
    }
}
