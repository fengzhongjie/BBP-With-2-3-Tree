package org.example;


import com.google.ortools.linearsolver.MPConstraint;
import com.google.ortools.linearsolver.MPObjective;
import com.google.ortools.linearsolver.MPSolver;
import com.google.ortools.linearsolver.MPVariable;
import com.google.ortools.Loader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import static com.google.ortools.linearsolver.MPSolver.createSolver;

public class BinPackingSolver {



    public Model readFile(String filePath) {
        Model model = new Model();
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));

            String line;
            int lineCount = 0;
            while ((line = bufferedReader.readLine()) != null) {
                if (lineCount == 0) {
                    model.numItems = Integer.parseInt(line);
                } else if (lineCount == 1) {
                    model.binCapacity = Integer.parseInt(line);
                    model.weights = new int[model.numItems];
                } else if (lineCount <= model.numItems + 1) {
                    model.weights[lineCount - 2] = Integer.parseInt(line);
                }
                lineCount++;
            }

            bufferedReader.close();
            model.numBins = model.numItems;
            System.out.println("Number of items: " + model.numItems);
            System.out.println("Bin capacity: " + model.binCapacity);
            System.out.println("Item sizes: ");
            for (int size : model.weights) {
                System.out.println(size);
            }

        } catch (IOException e) {
            e.printStackTrace(); // Handle or log the exception
        } catch (NumberFormatException e) {
            e.printStackTrace(); // Handle the case where parsing integers fails
        }
        return model;
    }

    public void solveBBP(String filePath) throws Exception{

        Loader.loadNativeLibraries();
        Model model;
        model = readFile(filePath);
        final DataModel data = new DataModel(model.weights, model.numItems, model.numBins, model.binCapacity);

        // Create the linear solver with the SCIP backend.
        MPSolver solver = MPSolver.createSolver("SCIP");
        if (solver == null) {
            System.out.println("Could not create solver SCIP");
            return;
        }

        MPVariable[][] x = new MPVariable[data.numItems][data.numBins];
        for (int i = 0; i < data.numItems; ++i) {
            for (int j = 0; j < data.numBins; ++j) {
                x[i][j] = solver.makeIntVar(0, 1, "");
            }
        }
        MPVariable[] y = new MPVariable[data.numBins];
        for (int j = 0; j < data.numBins; ++j) {
            y[j] = solver.makeIntVar(0, 1, "");
        }

        double infinity = java.lang.Double.POSITIVE_INFINITY;
        for (int i = 0; i < data.numItems; ++i) {
            MPConstraint constraint = solver.makeConstraint(1, 1, "");
            for (int j = 0; j < data.numBins; ++j) {
                constraint.setCoefficient(x[i][j], 1);
            }
        }
        // The bin capacity contraint for bin j is
        //   sum_i w_i x_ij <= C*y_j
        // To define this constraint, first subtract the left side from the right to get
        //   0 <= C*y_j - sum_i w_i x_ij
        //
        // Note: Since sum_i w_i x_ij is positive (and y_j is 0 or 1), the right side must
        // be less than or equal to C. But it's not necessary to add this constraint
        // because it is forced by the other constraints.

        for (int j = 0; j < data.numBins; ++j) {
            MPConstraint constraint = solver.makeConstraint(0, infinity, "");
            constraint.setCoefficient(y[j], data.binCapacity);
            for (int i = 0; i < data.numItems; ++i) {
                constraint.setCoefficient(x[i][j], -data.weights[i]);
            }
        }

        MPObjective objective = solver.objective();
        for (int j = 0; j < data.numBins; ++j) {
            objective.setCoefficient(y[j], 1);
        }
        objective.setMinimization();

        final MPSolver.ResultStatus resultStatus = solver.solve();

        // Check that the problem has an optimal solution.
        if (resultStatus == MPSolver.ResultStatus.OPTIMAL) {
            System.out.println("Number of bins used: " + objective.value());
            double totalWeight = 0;
            for (int j = 0; j < data.numBins; ++j) {
                if (y[j].solutionValue() == 1) {
                    System.out.println("\nBin " + j + "\n");
                    double binWeight = 0;
                    for (int i = 0; i < data.numItems; ++i) {
                        if (x[i][j].solutionValue() == 1) {
                            System.out.println("Item " + i + " - weight: " + data.weights[i]);
                            binWeight += data.weights[i];
                        }
                    }
                    System.out.println("Packed bin weight: " + binWeight);
                    totalWeight += binWeight;
                }
            }
            System.out.println("\nTotal packed weight: " + totalWeight);
        } else {
            System.err.println("The problem does not have an optimal solution.");
        }
    }

}
