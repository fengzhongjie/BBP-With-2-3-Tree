package org.example;

public class Model {
    public int numItems = -1;
    public int binCapacity = -1;
    public int[] weights = null;
    public int numBins = -1;
}